# LEGO Movie Maker

Ein kleines browserbasiertes Stop-Motion-Studio.

## Veröffentlichen mit GitHub Pages
1. Lade `index.html` in das Hauptverzeichnis deines Repositorys `lego-movie-maker`.
2. Falls GitHub fragt, bestätige **Commit changes**.
3. Öffne **Settings → Pages**. Wähle `Deploy from a branch`, Branch `main` und Ordner `/(root)`.
4. Warte ein paar Minuten. Die Seite sollte unter `https://gamer-king14.github.io/lego-movie-maker/` erreichbar sein.

Die Kamera funktioniert nur über eine sichere Verbindung (HTTPS) oder localhost. Videoexport verwendet WebM; die Unterstützung hängt vom Browser ab.
